// Your JavaScript code can go here
console.log("Welcome to MikuMiku <3");
